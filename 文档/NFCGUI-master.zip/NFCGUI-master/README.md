NFCGUI
=========

一款图形化NFC协议安全分析工具，主要针对Mifare卡，基于libnfc完成。

